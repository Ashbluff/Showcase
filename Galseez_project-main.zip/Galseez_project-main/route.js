latitude = 52.9562808;
longtitude = 4.7607972;

document.addEventListener('DOMContentLoaded', function () {
    var map = L.map('map').setView([latitude, longtitude], 13); // Set to your desired center

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    L.Routing.control({
        waypoints: [
            L.latLng(latitude, longtitude),
            L.latLng(latitude, longtitude)
        ],
        routeWhileDragging: true
    }).addTo(map);
});