<?php
include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$xCoord = $data['xCoord'];
$yCoord = $data['yCoord'];
$soortMarker = $data['soortMarker'];
$status = $data['status'];
$zichtbaar = $data['zichtbaar'];
$naamMarker = $data['naamMarker'];

// Update marker in the database
$sql = "UPDATE markers SET xCoord='$xCoord', yCoord='$yCoord', soortMarker='$soortMarker', status='$status', zichtbaar='$zichtbaar', naamMarker='$naamMarker' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Marker updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
