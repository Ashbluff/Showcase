<?php
include 'includes/connect.php':

$id = $_POST['id'];

$sql = "UPDATE markers SET order_strike = TRUE WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
  echo "Command send successfully";
} else {
  echo "Error: " . $conn->error;
}

$conn->close();
?>
