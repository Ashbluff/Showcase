
<!-- <?php
include 'Includes/nav.php';
if ($_SESSION['recht'] == 1) {
// Database connection
include 'Includes/connect.php'; }


$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];

// Delete marker from the database
$sql = "DELETE FROM markers WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    echo "Marker deleted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();


?> -->

