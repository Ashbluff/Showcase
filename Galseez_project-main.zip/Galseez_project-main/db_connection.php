<?php
$servername = 'localhost'; // Externe server IP-adres
$user = 'root'; // Externe server gebruikersnaam
$pass = ''; // Externe server wachtwoord
$db = 'galseez'; // Externe database naam

// Establish the database connection
$conn = new mysqli($servername, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
