<?php if (session_status() !== PHP_SESSION_ACTIVE) session_start(); ?>

    <script>
        document.getElementById("burger").addEventListener("click", function() {
            document.getElementById("dropdown").classList.toggle("active");
        });
    </script>

        <ul>
            <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) { ?>
                <li><a>logged in as: <?php echo $_SESSION['username']; ?></a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php } else { ?>
                <li><a href="login.php" class="profile">
                        Login
                    </a></li>
                    
            <?php } ?>

        </ul>
