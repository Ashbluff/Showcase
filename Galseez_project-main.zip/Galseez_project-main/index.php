<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wouten</title>
    <link rel="stylesheet" href="css/jip.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        #map {
            height: 600px;
            width: 100%;
            z-index: 0;
            background-color: black;
        }
    </style>
</head>
<body>

<?php
header("refresh: 5;");
?>

    <div class="header">
        <img src="img/galzees logo.png" alt="Logo"> <!-- Vervang met het juiste logo -->
        <div class="title">galseez</div>
        <?php include 'includes/nav.php'; ?>
        <div style="width: 50px;"></div> <!-- Placeholder voor symmetrie -->
    </div>
    <div id="map" class="map-container">
        <!-- Hier zou de kaart komen -->
    </div>
    <div class="footer">
        <button class="add-button" id="toggleMenuButton" onclick="toggleMenu()">+</button>
    </div>

    <div class="side-menu" id="menu">
        <h1>Marker toevoegen/bewerken</h1>
        <form id="markerForm">
            <input type="hidden" id="markerId">
            <input type="text" id="yCoord" placeholder="y coord/latitude">
            <input type="text" id="xCoord" placeholder="x coord/longitude">
            
            <select id="soortMarker">
                <option value="" disabled selected>soort marker</option>
                <option value="boot">boot</option>
                <option value="olieplatform">olieplatform</option>
                <option value="basis">basis</option>
                <option value="windmolenPark">windmolen Park</option>
            </select>
            <select id="status">
                <option value="" disabled selected>Status</option>
                <option value="vijand">vijand</option>
                <option value="neutraal">neutraal</option>
                <option value="vriend">vriend</option>
                <option value="obstakel">obstakel</option>
            </select>
            <select id="zichtbaar">
                <option value="" disabled selected>Zichtbaarheid</option>
                <option value="zichtbaar">zichtbaar</option>
                <option value="onzichtbaar">onzichtbaar</option>
            </select>
            <input type="text" id="naamMarker" placeholder="naam marker...">
            <button type="submit">voeg toe/bewerk</button>
            <button onclick="order_strikeMarker(${id}, marker)">order strike</button>
      </form>
    </div>

    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script>
        let currentMarkerId = null;
        const menu = document.getElementById('menu');
        const toggleMenuButton = document.getElementById('toggleMenuButton');
        menu.style.display = 'none';

        const socket = new WebSocket("ws://localhost:8080");

        document.getElementById('markerForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const markerId = document.getElementById('markerId').value;
            const xCoord = document.getElementById('xCoord').value;
            const yCoord = document.getElementById('yCoord').value;
            const soortMarker = document.getElementById('soortMarker').value;
            const status = document.getElementById('status').value;
            const zichtbaar = document.getElementById('zichtbaar').value;
            const naamMarker = document.getElementById('naamMarker').value;
            
            if (xCoord === '' || yCoord === '' || soortMarker === '' || status === '' || zichtbaar === '' || naamMarker === '') {
                console.log('Foutje gemaakt, eh? Zorg ervoor dat alle velden zijn ingevuld.');
                return;
            }

            const markerData = {
                action: markerId ? 'update' : 'add',
                id: markerId,
                xCoord,
                yCoord,
                soortMarker,
                status,
                zichtbaar,
                naamMarker
            };

            socket.send(JSON.stringify(markerData));

            fetch(markerId ? 'update_marker.php' : 'add_marker.php', {
                method: 'POST',
                body: JSON.stringify(markerData),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });


        function deleteMarker() {
            const markerId = document.getElementById('markerId').value;
            if (markerId) {
                const markerData = { action: 'delete', id: markerId };
                socket.send(JSON.stringify(markerData));

                fetch('delete_marker.php', {
                    method: 'POST',
                    body: JSON.stringify(markerData),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                    location.reload();
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        }


        const map = L.map('map').setView([51.505, -0.09], 2);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            noWrap: true,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map); 

        const bounds = [
            [85, -180],
            [-85, 180]
        ];

        map.setMaxBounds(bounds);
        map.options.maxBoundsViscosity = 1.0;

        map.options.minZoom = 2;
        map.options.maxZoom = 18;
        map.options.zoomSnap = 0.5;
        map.options.zoomDelta = 0.5;

        const icons = {
            boot: {
                vijand: L.icon({ iconUrl: 'icons/boat_enemy.png', iconSize: [85.33, 40.67] }),
                neutraal: L.icon({ iconUrl: 'icons/boat_neutral.png', iconSize: [85.33, 40.67] }),
                vriend: L.icon({ iconUrl: 'icons/boat_friend.png', iconSize: [85.33, 40.67] }),
                obstakel: L.icon({ iconUrl: 'icons/boat_obstacle.png', iconSize: [85.33, 40.67] })
            },
            olieplatform: {
                vijand: L.icon({ iconUrl: 'icons/platform_enemy.png', iconSize: [85.33, 40.67] }),
                neutraal: L.icon({ iconUrl: 'icons/platform_neutral.png', iconSize: [85.33, 40.67] }),
                vriend: L.icon({ iconUrl: 'icons/platform_friend.png', iconSize: [85.33, 40.67] }),
                obstakel: L.icon({ iconUrl: 'icons/platform_obstacle.png', iconSize: [85.33, 40.67] })
            },
            basis: {
                vijand: L.icon({ iconUrl: 'icons/base_enemy.png', iconSize: [85.33, 40.67] }),
                neutraal: L.icon({ iconUrl: 'icons/base_neutral.png', iconSize: [85.33, 40.67] }),
                vriend: L.icon({ iconUrl: 'icons/base_friend.png', iconSize: [85.33, 40.67] }),
                obstakel: L.icon({ iconUrl: 'icons/base_obstacle.png', iconSize: [85.33, 40.67] })
            },
            windmolenPark: {
                vijand: L.icon({ iconUrl: 'icons/tank_enemy.png', iconSize: [85.33, 40.67] }),
                neutraal: L.icon({ iconUrl: 'icons/tank_neutral.png', iconSize: [85.33, 40.67] }),
                vriend: L.icon({ iconUrl: 'icons/tank_friend.png', iconSize: [85.33, 40.67] }),
                obstakel: L.icon({ iconUrl: 'icons/tank_obstacle.png', iconSize: [85.33, 40.67] })
            }
        };


        function fetchMarkers() {
            fetch('get_markers.php', {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                if (Array.isArray(data)) {
                    data.forEach(marker => {
                        const markerIcon = icons[marker.soortMarker][marker.status];
                        const leafletMarker = L.marker([marker.yCoord, marker.xCoord], { icon: markerIcon })
                            .bindPopup(`<b>${marker.naamMarker}</b><br>${marker.soortMarker}`)
                            .addTo(map);

                        leafletMarker.on('click', () => {
                            document.getElementById('markerId').value = marker.id;
                            document.getElementById('xCoord').value = marker.xCoord;
                            document.getElementById('yCoord').value = marker.yCoord;
                            document.getElementById('soortMarker').value = marker.soortMarker;
                            document.getElementById('status').value = marker.status;
                            document.getElementById('zichtbaar').value = marker.zichtbaar;
                            document.getElementById('naamMarker').value = marker.naamMarker;
                            currentMarkerId = marker.id;
                            document.getElementById('deleteMarkerButton').style.display = 'block';
                            if (menu.style.display === 'none') {
                                toggleMenu();
                            }
                        });
                    });

                } else {
                    console.error('Unexpected response data:', data);
                }

            })
            .catch(error => {
                console.error('Error fetching markers:', error);
            });
        }

        fetchMarkers();

        function toggleMenu() {
            if (menu.style.display === 'none') {
                menu.style.display = 'block';
                toggleMenuButton.style.backgroundColor = "red";
                toggleMenuButton.textContent = '-';
            } else {
                menu.style.display = 'none';
                toggleMenuButton.textContent = '+';
                toggleMenuButton.style.backgroundColor = "#4CAF50";
                document.getElementById('deleteMarkerButton').style.display = 'none';
                currentMarkerId = null;
                document.getElementById('markerForm').reset();
            }
        }

        function onMapClick(e) {
            const lat = e.latlng.lat;
            const lng = e.latlng.lng;

            document.getElementById('markerId').value = '';
            document.getElementById('xCoord').value = lng;
            document.getElementById('yCoord').value = lat;
            document.getElementById('soortMarker').value = '';
            document.getElementById('status').value = '';
            document.getElementById('zichtbaar').value = '';
            document.getElementById('naamMarker').value = '';

            if (menu.style.display === 'none') {
                toggleMenu();
            }

            currentMarkerId = null;
            document.getElementById('deleteMarkerButton').style.display = 'none';

            console.log("You clicked the map at ycoord/latitude: " + lat + " and xcoord/longitude: " + lng);
        }

        map.on('click', onMapClick);



        // WebSocket logic to update markers in real-time
        let socket = new WebSocket("ws://localhost:8080");


        socket.onmessage = function(event) {
            const markerData = JSON.parse(event.data);
            const { action, id, xCoord, yCoord, soortMarker, status, zichtbaar, naamMarker } = markerData;

            if (action === 'add') {
                addMarkerToMap({ id, xCoord, yCoord, soortMarker, status, zichtbaar, naamMarker });
            } else if (action === 'update') {
                updateMarkerOnMap({ id, xCoord, yCoord, soortMarker, status, zichtbaar, naamMarker });
            } else if (action === 'delete') {
                deleteMarkerFromMap(id);
            }
        };

        function addMarkerToMap(marker) {
            const markerIcon = icons[marker.soortMarker][marker.status];
            const leafletMarker = L.marker([marker.yCoord, marker.xCoord], { icon: markerIcon })
                .bindPopup(`<b>${marker.naamMarker}</b><br>${marker.soortMarker}`)
                .addTo(map);


            leafletMarker.on('click', () => {
                document.getElementById('markerId').value = marker.id;
                document.getElementById('xCoord').value = marker.xCoord;
                document.getElementById('yCoord').value = marker.yCoord;
                document.getElementById('soortMarker').value = marker.soortMarker;
                document.getElementById('status').value = marker.status;
                document.getElementById('zichtbaar').value = marker.zichtbaar;
                document.getElementById('naamMarker').value = marker.naamMarker;
                currentMarkerId = marker.id;
                document.getElementById('deleteMarkerButton').style.display = 'block';
                if (menu.style.display === 'none') {
                    toggleMenu();
                }
            });
        }

        function updateMarkerOnMap(marker) {
            // Remove the old marker
            deleteMarkerFromMap(marker.id);
            // Add the updated marker
            addMarkerToMap(marker);
        }

        function deleteMarkerFromMap(markerId) {
            map.eachLayer((layer) => {
                if (layer instanceof L.Marker) {
                    if (layer.options.icon.options.markerId === markerId) {
                        map.removeLayer(layer);
                    }
                }
            });
        }

        };

      

        function deleteNotificationMarker(id) {
            fetch('delete_marker.php', {
                method: 'POST',
                body: JSON.stringify({ id: id }),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.text())
            .then(data => {
                alert(data);
                location.reload();
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }


// testing order strike 


function order_strikeMarker(id, marker) {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "order_strike_marker.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      alert(xhr.responseText);
      fetchOrderStrikeMarkers(); // Update the div with ordered markers
    }
  };
  xhr.send(`id=${id}`);
}

function addInfoWindow(marker, id) {
  const infowindow = new google.maps.InfoWindow({
    content: `<p>${marker.description}</p><button onclick="order_strikeMarker(${id}, marker)">order strike</button>`
  });

  marker.addListener('click', () => {
    infowindow.open(map, marker);
  });
}

function fetchOrderStrikeMarkers() {
  const xhr = new XMLHttpRequest();
  xhr.open("GET", "get_order_strike_markers.php", true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      const markers = JSON.parse(xhr.responseText);
      const markerList = document.getElementById('order_strikeMarkers');
      markerList.innerHTML = ''; // Clear the existing list

      markers.forEach(markerData => {
        const markerItem = document.createElement('div');
        markerItem.innerHTML = `<p>${markerData.description} 
                                <button onclick="deleteOrderStrikeMarker(${markerData.id})">Delete</button></p>`;
        markerList.appendChild(markerItem);
      });
    }
  };
  xhr.send();
}


function deleteOrderSreikeMarker(id) {
  const xhr = new XMLHttpRequest();
  xhr.open("POST", "delete_order_strike_marker.php", true);
  xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      alert(xhr.responseText);
      fetchOrderStrikeMarkers(); // Update the div with archived markers
      fetchMarkers(); // Update the map with the remaining markers
    }
  };
  xhr.send(`id=${id}`);
}






        


    </script>

</body>
</html>