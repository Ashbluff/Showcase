<?php
include "includes/connect.php";

$id = $_POST['id'];

$sql = "DELETE FROM markers WHERE id = '$id'";

if ($conn->query($sql) === TRUE) {
  echo "Marker deleted successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
