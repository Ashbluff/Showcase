<!DOCTYPE html>
<html lang="en">
 <!-- voeg toe dat je hier alleen maar met het huiste recht in kan -->
<head>

  <link rel="stylesheet" href="css/login.css">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, user-scalable=0" />
  <title>Galseez</title>
  <meta name="description" content="Galseez" />

  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

</head>

<body>

<?php
session_start();

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['recht']) || $_SESSION['recht'] != 1) {
    // Stuur de gebruiker door naar een andere pagina
    header("Location: index.php");
    exit(); // Zorg ervoor dat het script stopt na het doorsturen
}

// De rest van je index.php-code hieronder
?>
  <?php include 'includes/nav.php'; ?>

    <div class="login-container">
        <!-- <img src="imgs/loginLogo.svg"> -->
        <h2>Register</h2>
        <form action="Registreren.php" method="POST">
            <input id="user" name="username" placeholder="Username" type="text" class="input" required>
            <input id="email" name="email" placeholder="Email" type="text" class="input" required>
            <div class="password">
                <input id="pass" name="pwd" placeholder="Password" type="password" class="input" data-type="password" required>
                <input id="pass" name="retype_pwd" placeholder="Repeat Password" type="password" class="input" data-type="password" required>
            </div>
            <input type="submit" class="button" name="register_submit" value="Sign Up">
        </form>
        <a href="login.php">Login</a>
    </div>


  <?php

  include 'includes/connect.php';

  function validateData($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
  }


  // Form handling
  if (isset($_POST['register_submit']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
      $unf_pwd = $_POST['pwd'];
      $unf_retype_pwd = $_POST['retype_pwd'];
      $unf_email = $_POST['email'];
      $unf_username = $_POST['username'];

      // Data validation
      $pwd = validateData($unf_pwd);
      $retype_pwd = validateData($unf_retype_pwd);
      $email = validateData($unf_email);
      $username = validateData($unf_username);

      // Form filtering
      if ($pwd !== $retype_pwd) {
          echo "<p id='signupMsg'>Passwords don't match.</p>";
          return;
      }
      if (strlen($pwd) < 8) {
          echo "<p id='signupMsg'>Password too weak.</p>";
          return;
      }
      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          echo "<p id='signupMsg'>Email does not exist.</p>";
          return;
      }

      // Check if email already exists
      $stmt_check_email = $conn->prepare("SELECT userEmail FROM users WHERE userEmail = ?");
      $stmt_check_email->bind_param("s", $email);
      $stmt_check_email->execute();
      $stmt_check_email->store_result();
      if ($stmt_check_email->num_rows > 0) {
          echo "<p id='signupMsg'>Email already in use.</p>";
          return;
      }

      // Hash password
      $pwd_hash = password_hash($pwd, PASSWORD_DEFAULT);

      // Insert user data into the database
      $stmt_insert_user = $conn->prepare("INSERT INTO users (userEmail, userpassWD, userName) VALUES (?, ?, ?)");
      $stmt_insert_user->bind_param("sss", $email, $pwd_hash, $username);
      if ($stmt_insert_user->execute()) {
          echo "<p id='signupMsg'>Account successfully created.</p>";
          header('Location: login.php'); // Redirect to login page
          exit(); // Stop further execution
      } else {
          echo "<p id='signupMsg'>Something went wrong trying to create your account, wait a bit and try again.</p>";
      }
  }

  ?>




<!-- <?php include 'includes/footer.php'; ?> -->
</body>

</html>