<?php
include "includes/connect.php";

$sql = "SELECT id, latitude, longitude, description FROM markers WHERE order_strike = TRUE";
$result = $conn->query($sql);

$markers = array();

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $markers[] = $row;
  }
}

echo json_encode($markers);

$conn->close();
?>
