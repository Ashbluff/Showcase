<?php
session_start();
include 'includes/connect.php';

// Check if the user has the required permission (recht 1)
if ($_SESSION['recht'] != 1) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit;
}

// Prepare the SQL query to fetch notifications
$sql = "SELECT n.id, m.naamMarker, m.soortMarker, m.xCoord, m.yCoord
        FROM notifications n
        JOIN markers m ON n.marker_id = m.id";

$result = $conn->query($sql);

// Check for errors
if ($conn->error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database query error: ' . $conn->error]);
    exit;
}

$notifications = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($notifications);
?>
