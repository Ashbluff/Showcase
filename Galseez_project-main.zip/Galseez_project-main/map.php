<!DOCTYPE html>
<html>
<head>
    <title>Map</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        #map {
            height: 100vh; /* Of een specifieke hoogte zoals 500px */
            width: 100%;
        }
    </style>
</head>
<body>
    <div id="map" class="map"></div>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script src="route.js"></script>
</body>
</html>
