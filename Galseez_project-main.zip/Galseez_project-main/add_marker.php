<?php
include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

$xCoord = $data['xCoord'];
$yCoord = $data['yCoord'];
$soortMarker = $data['soortMarker'];
$status = $data['status'];
$zichtbaar = $data['zichtbaar'];
$naamMarker = $data['naamMarker'];

// Insert marker into the database
$sql = "INSERT INTO markers (xCoord, yCoord, soortMarker, status, zichtbaar, naamMarker) VALUES ('$xCoord', '$yCoord', '$soortMarker', '$status', '$zichtbaar', '$naamMarker')";

if ($conn->query($sql) === TRUE) {
    echo "Marker added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
